package src;

import src.brick_strategies.CollisionStrategy;
import danogl.GameManager;
import danogl.GameObject;
import danogl.gui.*;
import danogl.gui.rendering.Renderable;
import danogl.util.Counter;
import danogl.util.Vector2;
import src.gameobjects.*;

import java.awt.event.KeyEvent;
import java.util.Random;

public class BrickerGameManager extends GameManager {

    private UserInputListener inputListener;
    private final static int VISUALS_LAYER = -1;

    /**Window Properties**/
    private WindowController windowController;
    private Vector2 windowDimensions;
    private static final Vector2 WINDOW_DIMENSIONS = new Vector2(700, 500);
    private static final String WINDOW_TITLE = "Bricker";
    private static final String BACKGROUND_IMAGE_PATH = "assets/DARK_BG2_small.jpeg";

    /**Border Properties**/
    private static final int BORDER_SIZE = 10;

    /**Ball Properties**/
    private Ball ball;
    private static final Vector2 BALL_DIMENSIONS = new Vector2(20, 20);
    private static final int BALL_SPEED = 200;
    private static final String BALL_IMAGE_PATH = "assets/ball.png";
    private static final String BALL_SOUND_PATH = "assets/blop_cut_silenced.wav";

    /**Paddle Properties**/
    private static final Vector2 PADDLE_DIMENSIONS = new Vector2(100,10);
    private static final int minDistFromEdge = 45;
    private static final String PADDLE_IMAGE_PATH = "assets/paddle.png";

    /**Prompt Message Properties**/
    private static final String WIN = "You Win!";
    private static final String LOSE = "You Lose!";
    private static final String PLAY_AGAIN = " Play Again?";

    /**Life Properties**/
    private static final String HEART_IMAGE_PATH = "assets/heart.png";
    private static final Counter LIVES_COUNTER = new Counter();
    private static final int INITIAL_LIFE_COUNT = 3;
    private static final Vector2 NUMBER_DIMENSIONS = new Vector2(20,20);

    /**Brick Properties**/
    private static final int BRICK_ROWS = 8;
    private static final int BRICK_COLS = 7;
    public static final String BRICK_IMAGE_PATH = "assets/brick.png";
    public static final Counter BRICKS_COUNTER = new Counter();
    public static final Vector2 BRICK_DIMENSIONS = new Vector2(80, 20);
    public static final Vector2 UPPER_LEFT_BRICK_LOCATION = new Vector2(65, 30);

    /******************
    /**Public Methods**
    *******************/

    /**
     * Constructor of the game manager
     * @param windowTitle name of the game (displayed in the actual window)
     * @param windowDimensions dimensions of the window
     */
    public BrickerGameManager(String windowTitle, Vector2 windowDimensions) {
        super(windowTitle, windowDimensions);
    }

    /**
     * The update method that is called every frame, to render the game in the window.
     * @param deltaTime The time, in seconds, that passed since the last invocation
     *                  of this method (i.e., since the last frame). This is useful
     *                  for either accumulating the total time that passed since some
     *                  event, or for physics integration (i.e., multiply this by
     *                  the acceleration to get an estimate of the added velocity or
     *                  by the velocity to get an estimate of the difference in position).
     */
    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        checkForGameEnd();
    }

    /**
     * The function to initialize a new game.
     * @param imageReader Contains a single method: readImage, which reads an image from disk.
     *                 See its documentation for help.
     * @param soundReader Contains a single method: readSound, which reads a wav file from
     *                    disk. See its documentation for help.
     * @param inputListener Contains a single method: isKeyPressed, which returns whether
     *                      a given key is currently pressed by the user or not. See its
     *                      documentation.
     * @param windowController Contains an array of helpful, self-explanatory methods
     *                         concerning the window.
     */
    @Override
    public void initializeGame(ImageReader imageReader, SoundReader soundReader,
                               UserInputListener inputListener, WindowController windowController) {
        super.initializeGame(imageReader, soundReader, inputListener, windowController);

        this.windowController = windowController;
        this.windowDimensions = windowController.getWindowDimensions();
        this.inputListener = inputListener;

        createBackground(imageReader);
        createBorders();
        createGraphicLifeCounter(imageReader);
        createNumericLifeCounter();
        createPaddle(imageReader, inputListener);
        createBall(imageReader, soundReader, windowDimensions);
        createBricks(imageReader);
    }

    /**
     * The main function to run a game
     * @param args given arguments by user
     */
    public static void main(String[] args) {
        new BrickerGameManager(WINDOW_TITLE, WINDOW_DIMENSIONS).run();
    }

    /******************
    **Private Methods**
    *******************/

    /**
     * Checks whether a game has finished. if it does, close the game window.
     */
    private void checkForGameEnd() {
        double ballHeight = ball.getCenter().y();
        String prompt = "";

        if(inputListener.isKeyPressed(KeyEvent.VK_W) || BRICKS_COUNTER.value() == 0) prompt = WIN;

        if(ballHeight > windowDimensions.y()) {
            LIVES_COUNTER.decrement();
            setBallVelocity();
            ball.setCenter(windowDimensions.mult(0.5f));
        }

        if(LIVES_COUNTER.value() == 0) prompt = LOSE;

        if(!prompt.isEmpty()){
            prompt += PLAY_AGAIN;
            if(windowController.openYesNoDialog(prompt)) windowController.resetGame();
            else windowController.closeWindow();
        }
    }

    /**
     * Creates a ball object
     * @param imageReader an object for the visual asset
     * @param soundReader an object for the sound asset
     * @param windowDimensions the dimensions of the window of which we want to create the ball inside
     */
    private void createBall(ImageReader imageReader, SoundReader soundReader, Vector2 windowDimensions){
        Renderable ballImage = imageReader.readImage(BALL_IMAGE_PATH,true);
        Sound collisionSound = soundReader.readSound(BALL_SOUND_PATH);
        ball = new Ball(Vector2.ZERO,BALL_DIMENSIONS,ballImage,collisionSound);

        setBallVelocity();

        ball.setCenter(windowDimensions.mult(0.5f));
        gameObjects().addGameObject(ball);
    }

    /**
     * Creates the movement vector of the ball
     */
    private void setBallVelocity(){
        float ballVelX = BALL_SPEED;
        float ballVelY = BALL_SPEED;

        //randomize the initial ball direction
        Random rand = new Random();
        if(rand.nextBoolean()) ballVelX *= (-1);
        if(rand.nextBoolean()) ballVelY *= (-1);

        ball.setVelocity(new Vector2(ballVelX, ballVelY));
    }

    /**
     * Creates the borders of the game
     */
    private void createBorders() {
        //left border
        gameObjects().addGameObject(new GameObject(Vector2.ZERO,
                new Vector2(BORDER_SIZE, windowDimensions.y()), null));

        //right border
        gameObjects().addGameObject(new GameObject(
                new Vector2(windowDimensions.x()-BORDER_SIZE, 0),
                new Vector2(BORDER_SIZE, windowDimensions.y()), null));

        //upper border
        gameObjects().addGameObject(new GameObject(Vector2.ZERO,
                new Vector2(windowDimensions.x(), BORDER_SIZE), null));
    }

    /**
     * Creates the paddle controlled by the user
     * @param imageReader an object for the visual asset
     * @param inputListener an object for detecting key pressing by the user
     */
    private void createPaddle(ImageReader imageReader, UserInputListener inputListener) {
        Renderable paddleImage = imageReader.readImage(PADDLE_IMAGE_PATH,false);
        GameObject paddle = new Paddle(Vector2.ZERO, PADDLE_DIMENSIONS,paddleImage,inputListener,
                windowDimensions,minDistFromEdge);
        paddle.setCenter(new Vector2(windowDimensions.x()/2, windowDimensions.y() - 10));
        gameObjects().addGameObject(paddle);
    }

    /**
     * Creates the background of the game
     * @param imageReader an object for the visual asset
     */
    public void createBackground(ImageReader imageReader) {
        Renderable backgroundImage = imageReader.readImage(BACKGROUND_IMAGE_PATH,false);
        GameObject background = new GameObject(Vector2.ZERO,windowDimensions,backgroundImage);
        gameObjects().addGameObject(background,VISUALS_LAYER);
    }

    /**
     * Creates the hearts representation of the life counter
     * @param imageReader an object for the visual asset
     */
    public void createGraphicLifeCounter(ImageReader imageReader) {
        Renderable heartImage = imageReader.readImage(HEART_IMAGE_PATH,false);
        LIVES_COUNTER.reset();
        LIVES_COUNTER.increaseBy(INITIAL_LIFE_COUNT);
        Vector2 leftHeartLocation = new Vector2(20, windowDimensions.y()-50);

        GraphicLifeCounter graphicLifeCounter = new GraphicLifeCounter(leftHeartLocation,Vector2.ZERO,
                LIVES_COUNTER,heartImage,gameObjects(),INITIAL_LIFE_COUNT);
        gameObjects().addGameObject(graphicLifeCounter);
    }

    /**
     * Creates the numeric representation of the life counter
     */
    public void createNumericLifeCounter() {
        Vector2 numberLocation = new Vector2(160, windowDimensions.y() - 45);

        NumericLifeCounter numericLifeCounter = new NumericLifeCounter(LIVES_COUNTER,numberLocation,
                NUMBER_DIMENSIONS,gameObjects());
        gameObjects().addGameObject(numericLifeCounter,VISUALS_LAYER);
    }

    /**
     * Creates the bricks in the game, by demands in pdf.
     * @param imageReader an object for the visual asset
     */
    private void createBricks(ImageReader imageReader) {
        BRICKS_COUNTER.reset();
        BRICKS_COUNTER.increaseBy(BRICK_ROWS*BRICK_COLS);

        Renderable brickImage = imageReader.readImage(BRICK_IMAGE_PATH,false);

        for (int row = 0; row < BRICK_ROWS; row++) {
            for (int col = 0; col < BRICK_COLS; col++) {
                Brick newBrick = new Brick(new Vector2(UPPER_LEFT_BRICK_LOCATION.x() +
                        BRICK_DIMENSIONS.x()*col,UPPER_LEFT_BRICK_LOCATION.y() + BRICK_DIMENSIONS.y()*row),
                        BRICK_DIMENSIONS, brickImage, new CollisionStrategy(gameObjects()),BRICKS_COUNTER);
                gameObjects().addGameObject(newBrick);

            }
        }
    }
}
