package src.gameobjects;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.gui.rendering.Renderable;
import danogl.util.Counter;
import danogl.util.Vector2;

public class GraphicLifeCounter extends GameObject {

    private int numOfLives; //presented number of life
    private static final int INIT_LIVES = 3;
    private static final int HEARTS_LAYER = -1;
    private final Counter livesCounter; //actual number of life
    private final GameObjectCollection gameObjectsCollection;
    private final GameObject[] hearts = new GameObject[3];
    private static final Vector2 dimensions = new Vector2(40,40);
    private static final int HEARTS_SPACING = 45;


    /**
     * Constructor
     * @param widgetTopLeftCorner the top left corner of the left most heart
     * @param widgetDimensions the dimension of each heart
     * @param livesCounter the counter which holds current lives count
     * @param widgetRenderable the image renderable of the hearts
     * @param gameObjectsCollection the collection of all game objects currently in the game
     * @param numOfLives number of current lives
     */
    public GraphicLifeCounter(Vector2 widgetTopLeftCorner, Vector2 widgetDimensions, Counter livesCounter,
                       Renderable widgetRenderable, GameObjectCollection gameObjectsCollection,
                       int numOfLives){

        super(widgetTopLeftCorner, widgetDimensions, widgetRenderable);

        this.numOfLives = numOfLives;
        this.livesCounter = livesCounter;
        this.gameObjectsCollection = gameObjectsCollection;
        createHearts();
    }

    /**
     *
     * @param deltaTime The time elapsed, in seconds, since the last frame. Can
     *                  be used to determine a new position/velocity by multiplying
     *                  this delta with the velocity/acceleration respectively
     *                  and adding to the position/velocity:
     *                  velocity += deltaTime*acceleration
     *                  pos += deltaTime*velocity
     */
    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        updateHearts();
    }

    /**
     * Creates the hearts display
     */
    private void createHearts(){
        for (int i = 0; i < livesCounter.value(); i++) {
            Vector2 topLeftCorner = new Vector2(getTopLeftCorner().x()+ i*HEARTS_SPACING,
                    getTopLeftCorner().y());
            hearts[i] = new GameObject(topLeftCorner, dimensions, renderer().getRenderable());
            gameObjectsCollection.addGameObject(hearts[i],HEARTS_LAYER);
        }
    }

    /**
     * Updates the hearts display
     */
    private void updateHearts(){
        numOfLives = livesCounter.value();
        if(numOfLives <INIT_LIVES){
            if(hearts[numOfLives] != null){
                gameObjectsCollection.removeGameObject(hearts[numOfLives],HEARTS_LAYER);
            }
        }
    }
}
