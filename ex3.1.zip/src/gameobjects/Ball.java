package src.gameobjects;

import danogl.GameObject;
import danogl.collisions.Collision;
import danogl.gui.Sound;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;

public class Ball extends GameObject {
    private final Sound collisionSound;

    /**
     * Constructor
     * @param topLeftCorner position of the top left corner of the ball in the window.
     * @param dimensions the dimensions of the ball
     * @param renderable the image object of the ball
     * @param sound the sound file object of the ball's collision.
     */
    public Ball(Vector2 topLeftCorner, Vector2 dimensions, Renderable renderable, Sound sound){
        super(topLeftCorner, dimensions, renderable);
        this.collisionSound = sound;
    }

    /**
     * A function to define what happens when the ball collides with other object
     * @param other The GameObject with which a collision occurred.
     * @param collision Information regarding this collision.
     *                  A reasonable elastic behavior can be achieved with:
     *                  setVelocity(getVelocity().flipped(collision.getNormal()));
     */
    public void onCollisionEnter(GameObject other, Collision collision){
        super.onCollisionEnter(other, collision);
        Vector2 velocity = getVelocity().flipped(collision.getNormal());
        setVelocity(velocity);
        collisionSound.play();
    }
}
